# Usage
## entry: makefile

default is using iverilog

## can also use verilator
see [https://bonany.cc/verilatorverilog/](https://bonany.cc/verilatorverilog/) for details

```make verilator```
then mannually run:
```
cd ./obj_dir
make -f Vtb.mk # <-- design changes here
./Vtb
# gtkwave outputWave.vcd
```

# Files
* tb.v: testbench
* mem.v: memory behavior model
* program.hex: program that is preloaded into memory