// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb___024root.h"

VL_ATTR_COLD void Vtb___024root___eval_initial__TOP(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf);

void Vtb___024root___eval_initial(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtb___024root___eval_initial__TOP(vlSelf);
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    Vtb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
}

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.tb_instr_mem__DOT__clk = 0U;
    vlSelfRef.tb_instr_mem__DOT__en = 0U;
    vlSelfRef.tb_instr_mem__DOT__we = 0U;
    vlSelfRef.tb_instr_mem__DOT__addr = 0U;
    vlSelfRef.tb_instr_mem__DOT__d[0U] = 0U;
    vlSelfRef.tb_instr_mem__DOT__d[1U] = 0U;
    vlSelfRef.tb_instr_mem__DOT__d[2U] = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x14ULL, nullptr, 
                                         "tb.v", 40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb_instr_mem__DOT__en = 1U;
    vlSelfRef.tb_instr_mem__DOT__we = 0U;
    vlSelfRef.tb_instr_mem__DOT__addr = 0U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 46);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Read from addr 0: q = 0x%x\n",0,94,
                 vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__addr = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Read from addr 1: q = 0x%x\n",0,94,
                 vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__we = 1U;
    vlSelfRef.tb_instr_mem__DOT__addr = 5U;
    vlSelfRef.tb_instr_mem__DOT__d[0U] = 0x78901234U;
    vlSelfRef.tb_instr_mem__DOT__d[1U] = 0x90123456U;
    vlSelfRef.tb_instr_mem__DOT__d[2U] = 0x12345678U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 57);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Wrote to addr 5: data = 0x%x\n",0,
                 94,vlSelfRef.tb_instr_mem__DOT__d.data());
    vlSelfRef.tb_instr_mem__DOT__we = 0U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 62);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Read from addr 5: q = 0x%x\n",0,94,
                 vlSelfRef.tb_instr_mem__DOT__q.data());
    if ((0U == (((0x78901234U ^ vlSelfRef.tb_instr_mem__DOT__q[0U]) 
                 | (0x90123456U ^ vlSelfRef.tb_instr_mem__DOT__q[1U])) 
                | (0x12345678U ^ vlSelfRef.tb_instr_mem__DOT__q[2U])))) {
        VL_WRITEF_NX("Data verification passed\n",0);
    } else {
        VL_WRITEF_NX("Data verification failed\n",0);
    }
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb_instr_mem__DOT__addr = 0U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 0: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 1U;
    vlSelfRef.tb_instr_mem__DOT__addr = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 1: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 2U;
    vlSelfRef.tb_instr_mem__DOT__addr = 2U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 2: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 3U;
    vlSelfRef.tb_instr_mem__DOT__addr = 3U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 3: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 4U;
    vlSelfRef.tb_instr_mem__DOT__addr = 4U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 4: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 5U;
    vlSelfRef.tb_instr_mem__DOT__addr = 5U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 5: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 6U;
    vlSelfRef.tb_instr_mem__DOT__addr = 6U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 6: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 7U;
    vlSelfRef.tb_instr_mem__DOT__addr = 7U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 7: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 8U;
    vlSelfRef.tb_instr_mem__DOT__addr = 8U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 8: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 9U;
    vlSelfRef.tb_instr_mem__DOT__addr = 9U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "tb.v", 75);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_WRITEF_NX("Addr 9: q = 0x%x\n",0,94,vlSelfRef.tb_instr_mem__DOT__q.data());
    vlSelfRef.tb_instr_mem__DOT__unnamedblk1__DOT__i = 0xaU;
    co_await vlSelfRef.__VdlySched.delay(0x14ULL, nullptr, 
                                         "tb.v", 80);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_FINISH_MT("tb.v", 81, "");
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

void Vtb___024root___eval_act(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_act\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf);

void Vtb___024root___eval_nba(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_nba\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
    }
}

VL_INLINE_OPT void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___nba_sequent__TOP__0\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<3>/*93:0*/ __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0;
    VL_ZERO_W(94, __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0);
    SData/*9:0*/ __VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0;
    __VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0 = 0;
    CData/*0:0*/ __VdlySet__tb_instr_mem__DOT__uut__DOT__data__v0;
    __VdlySet__tb_instr_mem__DOT__uut__DOT__data__v0 = 0;
    // Body
    __VdlySet__tb_instr_mem__DOT__uut__DOT__data__v0 = 0U;
    if (vlSelfRef.tb_instr_mem__DOT__en) {
        if (vlSelfRef.tb_instr_mem__DOT__we) {
            __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[0U] 
                = vlSelfRef.tb_instr_mem__DOT__d[0U];
            __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[1U] 
                = vlSelfRef.tb_instr_mem__DOT__d[1U];
            __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[2U] 
                = vlSelfRef.tb_instr_mem__DOT__d[2U];
            __VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0 
                = vlSelfRef.tb_instr_mem__DOT__addr;
            __VdlySet__tb_instr_mem__DOT__uut__DOT__data__v0 = 1U;
        }
        if ((1U & (~ (IData)(vlSelfRef.tb_instr_mem__DOT__we)))) {
            vlSelfRef.tb_instr_mem__DOT__q[0U] = vlSelfRef.tb_instr_mem__DOT__uut__DOT__data
                [vlSelfRef.tb_instr_mem__DOT__addr][0U];
            vlSelfRef.tb_instr_mem__DOT__q[1U] = vlSelfRef.tb_instr_mem__DOT__uut__DOT__data
                [vlSelfRef.tb_instr_mem__DOT__addr][1U];
            vlSelfRef.tb_instr_mem__DOT__q[2U] = vlSelfRef.tb_instr_mem__DOT__uut__DOT__data
                [vlSelfRef.tb_instr_mem__DOT__addr][2U];
        }
    }
    if (__VdlySet__tb_instr_mem__DOT__uut__DOT__data__v0) {
        vlSelfRef.tb_instr_mem__DOT__uut__DOT__data[__VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0][0U] 
            = __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[0U];
        vlSelfRef.tb_instr_mem__DOT__uut__DOT__data[__VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0][1U] 
            = __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[1U];
        vlSelfRef.tb_instr_mem__DOT__uut__DOT__data[__VdlyDim0__tb_instr_mem__DOT__uut__DOT__data__v0][2U] 
            = __VdlyVal__tb_instr_mem__DOT__uut__DOT__data__v0[2U];
    }
}

void Vtb___024root___timing_resume(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_resume\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf);

bool Vtb___024root___eval_phase__act(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__act\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vtb___024root___timing_resume(vlSelf);
        Vtb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtb___024root___eval_phase__nba(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__nba\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtb___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__nba(Vtb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb___024root___eval(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vtb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("tb.v", 5, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vtb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("tb.v", 5, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vtb___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vtb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtb___024root___eval_debug_assertions(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_debug_assertions\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
